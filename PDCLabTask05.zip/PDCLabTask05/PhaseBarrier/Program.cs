﻿// See https://aka.ms/new-console-template for more information
using System;
using System.Diagnostics;
using System.Threading;

class PhaseBarrier
{
    private readonly object gate = new object();

    private readonly int parties;
    private int waiting = 0;
    private long generation = 0;

    public PhaseBarrier(int parties)
    {
        this.parties = parties;
    }

    public void SignalAndWait()
    {
        lock (gate)
        {
            long myGeneration = generation;

            waiting++;

            if (waiting == parties)
            {
                waiting = 0;
                generation++;

                Monitor.PulseAll(gate);
            }
            else
            {
                while (myGeneration == generation)
                {
                    Monitor.Wait(gate);
                }
            }
        }
    }
}

class Program
{
    const int Rounds = 100_000;

    static int numWorkers = 4;
    static bool useBarrier = true;

    static ulong[] cells = Array.Empty<ulong>();

    static PhaseBarrier bar = null!;

    static void Sync()
    {
        if (useBarrier)
            bar.SignalAndWait();
    }

    static void Worker(int id)
    {
        for (int r = 0; r < Rounds; r++)
        {
            // Phase 1: read
            ulong next =
                cells[id] +
                cells[(id + 1) % numWorkers];

            // All workers finish reading
            Sync();

            // Phase 2: write
            cells[id] = next;

            // All workers finish writing
            Sync();
        }
    }

    static void Main(string[] args)
    {
        foreach (string arg in args)
        {
            if (arg == "--no-barrier")
            {
                useBarrier = false;
            }
            else
            {
                numWorkers = int.Parse(arg);
            }
        }

        cells = new ulong[numWorkers];

        ulong[] expected = new ulong[numWorkers];
        ulong[] temp = new ulong[numWorkers];

        for (int i = 0; i < numWorkers; i++)
        {
            cells[i] = (ulong)(i + 1);
            expected[i] = (ulong)(i + 1);
        }

        bar = new PhaseBarrier(numWorkers);

        Thread[] threads = new Thread[numWorkers];

        Stopwatch sw = Stopwatch.StartNew();

        for (int i = 0; i < numWorkers; i++)
        {
            int id = i;

            threads[i] = new Thread(
                () => Worker(id));

            threads[i].Start();
        }

        foreach (Thread t in threads)
            t.Join();

        sw.Stop();

        // Sequential reference calculation
        for (int r = 0; r < Rounds; r++)
        {
            for (int i = 0; i < numWorkers; i++)
            {
                temp[i] =
                    expected[i] +
                    expected[(i + 1) % numWorkers];
            }

            for (int i = 0; i < numWorkers; i++)
            {
                expected[i] = temp[i];
            }
        }

        int mismatches = 0;

        for (int i = 0; i < numWorkers; i++)
        {
            if (cells[i] != expected[i])
                mismatches++;
        }

        string label =
            useBarrier ? "barrier" : "no barrier";

        string correct =
            mismatches == 0 ? "YES" : "NO";

        Console.WriteLine(
            $"[{label}] workers={numWorkers} " +
            $"rounds={Rounds} " +
            $"matches_reference={correct} " +
            $"mismatching_cells={mismatches} " +
            $"time={sw.Elapsed.TotalMilliseconds:F2} ms");

        Console.WriteLine(
            $"Environment.ProcessorCount={Environment.ProcessorCount}");
    }
}