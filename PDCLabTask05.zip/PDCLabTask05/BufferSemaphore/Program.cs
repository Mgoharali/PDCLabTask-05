﻿using System;
using System.Diagnostics;
using System.Threading;

class Program
{
    const int ItemsPerProducer = 50_000;

    static int[] buffer = null!;
    static int inPos = 0;
    static int outPos = 0;

    static readonly object gate = new object();

    static SemaphoreSlim emptySlots = null!;
    static SemaphoreSlim fullSlots = null!;

    static int producers;
    static int consumers;
    static int bufferSize;
    static int totalItems;

    static int[] seen = null!;

    static long consumedSum = 0;
    static long duplicateCount = 0;
    static long invalidCount = 0;

    static void Producer(object? obj)
    {
        int producerId = (int)obj!;

        for (int i = 0; i < ItemsPerProducer; i++)
        {
            int itemId = producerId * ItemsPerProducer + i;

            // Wait until there is an empty slot.
            emptySlots.Wait();

            // Only protect the shared buffer/index update.
            lock (gate)
            {
                buffer[inPos] = itemId;
                inPos = (inPos + 1) % bufferSize;
            }

            // One more item is now available.
            fullSlots.Release();
        }
    }

    static void Consumer(object? obj)
    {
        for (int i = 0; i < totalItems / consumers; i++)
        {
            // Wait until there is an item to consume.
            fullSlots.Wait();

            int item;

            // Protect the shared buffer/index update.
            lock (gate)
            {
                item = buffer[outPos];
                outPos = (outPos + 1) % bufferSize;
            }

            // One buffer position is free again.
            emptySlots.Release();

            if (item < 0 || item >= totalItems)
            {
                Interlocked.Increment(ref invalidCount);
            }
            else
            {
                int previous = Interlocked.Increment(ref seen[item]);

                if (previous != 1)
                    Interlocked.Increment(ref duplicateCount);

                Interlocked.Add(ref consumedSum, item);
            }
        }
    }

    static void Main(string[] args)
    {
        // Default configuration
        producers = 1;
        consumers = 1;
        bufferSize = 8;

        // Example:
        // dotnet run -- 4 4 64
        if (args.Length >= 3)
        {
            producers = int.Parse(args[0]);
            consumers = int.Parse(args[1]);
            bufferSize = int.Parse(args[2]);
        }

        totalItems = producers * ItemsPerProducer;

        if (totalItems % consumers != 0)
        {
            Console.WriteLine(
                "Error: total number of items must be divisible by number of consumers."
            );
            return;
        }

        buffer = new int[bufferSize];

        // emptySlots starts with the complete buffer capacity.
        emptySlots = new SemaphoreSlim(bufferSize, bufferSize);

        // No items are available initially.
        fullSlots = new SemaphoreSlim(0, totalItems);

        seen = new int[totalItems];

        Thread[] producerThreads = new Thread[producers];
        Thread[] consumerThreads = new Thread[consumers];

        Stopwatch sw = Stopwatch.StartNew();

        // Create producer threads.
        for (int i = 0; i < producers; i++)
        {
            int id = i;
            producerThreads[i] = new Thread(Producer);
            producerThreads[i].Start(id);
        }

        // Create consumer threads.
        for (int i = 0; i < consumers; i++)
        {
            consumerThreads[i] = new Thread(Consumer);
            consumerThreads[i].Start();
        }

        // Wait for all producers.
        foreach (Thread t in producerThreads)
            t.Join();

        // Wait for all consumers.
        foreach (Thread t in consumerThreads)
            t.Join();

        sw.Stop();

        long expectedSum = 0;

        for (int i = 0; i < totalItems; i++)
            expectedSum += i;

        int missing = 0;

        for (int i = 0; i < totalItems; i++)
        {
            if (seen[i] == 0)
                missing++;
        }

        Console.WriteLine(
            $"[SemaphoreSlim] producers={producers} " +
            $"consumers={consumers} buffer={bufferSize}"
        );

        Console.WriteLine(
            $"items={totalItems} expected_sum={expectedSum} " +
            $"actual_sum={consumedSum}"
        );

        Console.WriteLine(
            $"missing={missing} duplicates={duplicateCount} " +
            $"invalid={invalidCount}"
        );

        Console.WriteLine(
            $"checksum_ok={(expectedSum == consumedSum ? "YES" : "NO")} " +
            $"time={sw.Elapsed.TotalMilliseconds:F2} ms"
        );
    }
}