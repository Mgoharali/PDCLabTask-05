﻿// See https://aka.ms/new-console-template for more information
using System;
using System.Diagnostics;
using System.Threading;

class Program
{
    const int DelayMs = 1000;

    static readonly object gate = new object();

    static bool dataReady = false;
    static int sharedData = 0;

    static int[] waitCalls = Array.Empty<int>();

    static void Worker(int id)
    {
        lock (gate)
        {
            while (!dataReady)
            {
                waitCalls[id]++;
                Monitor.Wait(gate);
            }

            Console.WriteLine(
                $"Worker {id}: received data = {sharedData}");
        }
    }

    static void Publish(bool pulseAll)
    {
        Thread.Sleep(DelayMs);

        lock (gate)
        {
            sharedData = 42;
            dataReady = true;

            if (pulseAll)
                Monitor.PulseAll(gate);
            else
                Monitor.Pulse(gate);
        }
    }

    static void RunCondition(int workers, bool signalFirst)
    {
        dataReady = false;
        sharedData = 0;

        waitCalls = new int[workers];

        Thread[] threads = new Thread[workers];

        Stopwatch wall = Stopwatch.StartNew();

        Process process = Process.GetCurrentProcess();
        TimeSpan cpuStart = process.TotalProcessorTime;

        if (signalFirst)
        {
            lock (gate)
            {
                sharedData = 42;
                dataReady = true;
                Monitor.PulseAll(gate);
            }
        }

        for (int i = 0; i < workers; i++)
        {
            int id = i;
            threads[i] = new Thread(() => Worker(id));
            threads[i].Start();
        }

        if (!signalFirst)
        {
            Thread publisher = new Thread(
                () => Publish(workers > 1));

            publisher.Start();
            publisher.Join();
        }

        foreach (Thread t in threads)
            t.Join();

        wall.Stop();

        TimeSpan cpuEnd = process.TotalProcessorTime;
        TimeSpan cpuUsed = cpuEnd - cpuStart;

        int totalWaits = 0;

        foreach (int count in waitCalls)
            totalWaits += count;

        Console.WriteLine(
            $"workers={workers} signal_first={signalFirst}");

        Console.WriteLine(
            $"data={sharedData} total_wait_calls={totalWaits}");

        Console.WriteLine(
            $"wall_time={wall.Elapsed.TotalMilliseconds:F2} ms " +
            $"cpu_time={cpuUsed.TotalMilliseconds:F2} ms");
    }

    static void RunSpin()
    {
        dataReady = false;
        sharedData = 0;

        Stopwatch wall = Stopwatch.StartNew();

        Process process = Process.GetCurrentProcess();
        TimeSpan cpuStart = process.TotalProcessorTime;

        Thread worker = new Thread(() =>
        {
            while (!dataReady)
            {
                Thread.Yield();
            }

            Console.WriteLine(
                $"Worker: received data = {sharedData}");
        });

        worker.Start();

        Thread.Sleep(DelayMs);

        sharedData = 42;
        dataReady = true;

        worker.Join();

        wall.Stop();

        TimeSpan cpuEnd = process.TotalProcessorTime;
        TimeSpan cpuUsed = cpuEnd - cpuStart;

        Console.WriteLine(
            $"[spin] data={sharedData} " +
            $"wall_time={wall.Elapsed.TotalMilliseconds:F2} ms " +
            $"cpu_time={cpuUsed.TotalMilliseconds:F2} ms");
    }

    static void Main(string[] args)
    {
        string mode = args.Length > 0 ? args[0] : "cond";

        if (mode == "cond")
        {
            RunCondition(1, false);
        }
        else if (mode == "signal-first")
        {
            RunCondition(1, true);
        }
        else if (mode == "cond3")
        {
            RunCondition(3, false);
        }
        else if (mode == "spin")
        {
            RunSpin();
        }
        else
        {
            Console.WriteLine("Unknown option.");
            Console.WriteLine("Use:");
            Console.WriteLine("  cond");
            Console.WriteLine("  signal-first");
            Console.WriteLine("  cond3");
            Console.WriteLine("  spin");
        }
    }
}